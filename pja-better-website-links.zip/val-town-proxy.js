/**
 * backend/val-town-proxy.js
 * ─────────────────────────────────────────────────────────────────
 * Val.town HTTP handler — receives events from the PJA website
 * and forwards them as rich embeds to your Discord webhook.
 *
 * HOW TO DEPLOY ON VAL.TOWN:
 * 1. Go to https://www.val.town and create a free account.
 * 2. Create a new Val → choose "HTTP" type.
 * 3. Paste ALL of this code into the Val editor.
 * 4. In Val.town Environment Variables, add:
 *      DISCORD_WEBHOOK_URL = https://discord.com/api/webhooks/...
 * 5. Copy the Val's public URL (e.g. https://yourname.val.run/pja-webhook).
 * 6. Paste that URL into the Manager Dashboard → Settings → Discord Webhook.
 * 7. Enable the webhook toggle and click Save.
 *
 * SECURITY:
 * - DISCORD_WEBHOOK_URL is stored server-side in Val.town env vars.
 * - The raw Discord webhook URL is NEVER exposed to the browser.
 * - The website only knows your Val.town endpoint.
 * ─────────────────────────────────────────────────────────────────
 */

// ── Colour map for embed sidebar ────────────────────────────────────────────
const COLOURS = {
  tryout:        0x2563eb,  // blue
  profile:       0x7c3aed,  // purple
  selfReport:    0x059669,  // green
  motmVote:      0xf59e0b,  // gold
  finalReport:   0x0ea5e9,  // sky blue
  request:       0x6366f1,  // indigo
  bug:           0xef4444,  // red
  giveaway:      0x10b981,  // emerald
  scheduleUpd:   0x0891b2,  // cyan
  test:          0x64748b,  // slate gray
  default:       0x2563eb
};

// ── Build Discord embed from event payload ────────────────────────────────────
function buildEmbed(event, data) {
  const color  = COLOURS[event] || COLOURS.default;
  const ts     = data.timestamp || new Date().toISOString();

  const TITLES = {
    tryout:       '📋 New Tryout Application',
    profile:      '🪪 New Player Profile',
    selfReport:   '📊 Match Self-Report Submitted',
    motmVote:     '⭐ MOTM Vote Cast',
    finalReport:  '📄 Final Match Report',
    request:      '💬 Player Request',
    bug:          '🐛 Bug Report',
    giveaway:     '🎁 Giveaway',
    scheduleUpd:  '📅 Schedule Update',
    test:         '🔧 Test Notification',
  };

  const title = TITLES[event] || 'PJA Portal Event';

  // Build fields from data payload (filter system keys)
  const SKIP = ['timestamp','team','event'];
  const fields = Object.entries(data)
    .filter(([k]) => !SKIP.includes(k) && data[k] !== undefined && data[k] !== '')
    .slice(0, 20)
    .map(([k, v]) => ({
      name:   k.replace(/([A-Z])/g, ' $1').replace(/^./, s => s.toUpperCase()),
      value:  String(v).slice(0, 1024) || '—',
      inline: String(v).length < 40
    }));

  return {
    title,
    color,
    fields,
    footer: { text: `PJA Portal • ${data.team || 'Project Azure'}` },
    timestamp: ts
  };
}

// ── Main Val.town HTTP handler ───────────────────────────────────────────────
export default async function handler(req) {

  // CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 204,
      headers: {
        'Access-Control-Allow-Origin':  '*',
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type'
      }
    });
  }

  if (req.method !== 'POST') {
    return new Response('Method not allowed', { status: 405 });
  }

  // Parse request body
  let body;
  try {
    body = await req.json();
  } catch {
    return new Response('Invalid JSON', { status: 400 });
  }

  const { event, data = {} } = body;

  // Get Discord webhook URL from Val.town environment variables
  const webhookUrl = Deno.env.get('DISCORD_WEBHOOK_URL');
  if (!webhookUrl) {
    console.error('[PJA Proxy] DISCORD_WEBHOOK_URL not set in environment.');
    return new Response('Webhook not configured', { status: 500 });
  }

  // Build Discord message
  const embed   = buildEmbed(event, data);
  const content = event === 'test'
    ? '✅ **PJA Portal webhook is working!**'
    : '';

  const discordPayload = {
    content,
    embeds:   [embed],
    username: 'PJA Portal',
  };

  // Forward to Discord
  try {
    const res = await fetch(webhookUrl, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify(discordPayload)
    });

    if (!res.ok) {
      const errText = await res.text();
      console.error('[PJA Proxy] Discord error:', res.status, errText);
      return new Response('Discord webhook error: ' + errText, { status: 502, headers: { 'Access-Control-Allow-Origin': '*' } });
    }

    return new Response(JSON.stringify({ ok: true, event }), {
      status:  200,
      headers: {
        'Content-Type':                'application/json',
        'Access-Control-Allow-Origin': '*'
      }
    });
  } catch (err) {
    console.error('[PJA Proxy] fetch error:', err);
    return new Response('Failed to reach Discord: ' + err.message, {
      status:  502,
      headers: { 'Access-Control-Allow-Origin': '*' }
    });
  }
}
