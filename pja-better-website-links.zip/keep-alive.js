const http = require("http");

let onMatchReceived = null;
let onWebsiteSubmission = null;

function setMatchHandler(fn) {
  onMatchReceived = fn;
}

function setWebsiteSubmissionHandler(fn) {
  onWebsiteSubmission = fn;
}

function sendJson(res, status, payload) {
  res.writeHead(status, { "Content-Type": "application/json" });
  res.end(JSON.stringify(payload));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = "";
    req.on("data", chunk => {
      body += chunk;
      if (body.length > 1_000_000) {
        req.destroy();
        reject(new Error("Body too large"));
      }
    });
    req.on("end", () => {
      try { resolve(body ? JSON.parse(body) : {}); }
      catch { reject(new Error("Invalid JSON")); }
    });
    req.on("error", reject);
  });
}

const server = http.createServer(async (req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");

  if (req.method === "OPTIONS") {
    res.writeHead(204);
    res.end();
    return;
  }

  if (req.method === "GET") {
    if (req.url === "/" || req.url === "/health") {
      sendJson(res, 200, { ok: true, message: "PJA Bot is alive" });
      return;
    }
    sendJson(res, 404, { ok: false, error: "Not found" });
    return;
  }

  if (req.method === "POST" && req.url === "/match") {
    try {
      const data = await readBody(req);
      console.log("Match received from website:", data);
      if (!onMatchReceived) return sendJson(res, 503, { ok: false, error: "Bot not ready yet" });
      await onMatchReceived(data);
      return sendJson(res, 200, { ok: true });
    } catch (e) {
      console.error("/match error:", e.message);
      return sendJson(res, 400, { ok: false, error: e.message });
    }
  }

  if (req.method === "POST" && req.url === "/submit-report") {
    try {
      const data = await readBody(req);
      console.log("Website report submission received:", {
        reportId: data.reportId,
        playerId: data.playerId,
        ign: data.ign,
        position: data.position,
      });
      if (!onWebsiteSubmission) return sendJson(res, 503, { ok: false, error: "Bot not ready yet" });
      const result = await onWebsiteSubmission(data);
      return sendJson(res, 200, { ok: true, ...result });
    } catch (e) {
      console.error("/submit-report error:", e.message);
      return sendJson(res, 400, { ok: false, error: e.message });
    }
  }

  sendJson(res, 404, { ok: false, error: "Not found" });
});

server.listen(process.env.PORT || 8080, () => {
  console.log("Keep-alive/API server running on port " + (process.env.PORT || 8080));
});

module.exports = { setMatchHandler, setWebsiteSubmissionHandler };
